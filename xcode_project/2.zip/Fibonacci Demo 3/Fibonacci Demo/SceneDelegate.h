//
//  SceneDelegate.h
//  Fibonacci Demo
//
//  Created by 徐晗淋 on 2022/3/31.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

