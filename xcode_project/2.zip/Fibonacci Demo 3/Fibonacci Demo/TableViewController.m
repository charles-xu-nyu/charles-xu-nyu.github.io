//
//  TableViewController.m
//  Fibonacci Demo
//
//  Created by 徐晗淋 on 2022/3/31.
//

#import "TableViewController.h"
#import "FibonacciViewController.h"
#import "SliderDemoViewController.h"
#import "SineWaveDemo1UIViewController.h"
#import "SineWaveDemo2UIViewController.h"
#import "SineWaveDemo3ViewController.h"
#import "SineWaveDemo4ViewController.h"
@interface TableViewController ()
@property (nonatomic,strong)NSArray *dataArray;
@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.dataArray = @[@"Fibonacci series app 2",@"Slider Demo",@"Sine Wave Demo 1",@"Sine Wave Demo 2",@"Sine Wave Demo 3",@"Sine Wave Demo 4"];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.textLabel.text = self.dataArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        FibonacciViewController *vc = [[FibonacciViewController alloc]init];
        vc.title = self.dataArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (indexPath.row == 1) {
        SliderDemoViewController *vc = [[SliderDemoViewController alloc]init];
        vc.title = self.dataArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (indexPath.row == 2) {
        SineWaveDemo1UIViewController *vc = [[SineWaveDemo1UIViewController alloc]init];
        vc.title = self.dataArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (indexPath.row == 3) {
        SineWaveDemo2UIViewController *vc = [[SineWaveDemo2UIViewController alloc]init];
        vc.title = self.dataArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (indexPath.row == 4) {
        SineWaveDemo3ViewController *vc = [[SineWaveDemo3ViewController alloc]init];
        vc.title = self.dataArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    }   else if (indexPath.row == 5) {
        SineWaveDemo4ViewController *vc = [[SineWaveDemo4ViewController alloc]init];
        vc.title = self.dataArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    
    
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
