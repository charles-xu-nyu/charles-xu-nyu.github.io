//
//  SliderDemoViewController.m
//  Fibonacci Demo
//
//  Created by 徐晗淋 on 2022/3/31.
//

#import "SliderDemoViewController.h"

@interface SliderDemoViewController ()
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation SliderDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)sliderchange:(UISlider *)sender {
    int value = sender.value;
    self.label.text = [NSString stringWithFormat:@"%d",value];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
