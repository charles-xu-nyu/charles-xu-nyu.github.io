//
//  IntroductionView.swift
//  Demo1
//
//  Created by 徐晗淋 on 12/7/21.
//

import SwiftUI

struct IntroductionView: View {
    var body: some View {
        ScrollView{
            Text("Introduction to the project")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding([.top, .leading, .trailing])
            
            Text("Authored by Hanlin Xu")
                .font(.headline)
                .foregroundColor(.secondary)
                        
            Text("I. Introduction of ios platform")
                .font(.title)
                .fontWeight(.semibold)
                .multilineTextAlignment(.leading)
                .padding(.top)
            
            Text("     IOS stands for iPhone operating system. It is a proprietary mobile operating system of Apple for its handheld. It supports Objective-C, C, C++, Swift programming language. It is based on the Macintosh OS X. After Android, it is the world’s second most popular mobile operating system. Many of Apple’s mobile devices, including the iPhone, iPad, and iPod, run on this operating system. To control the device, iOS employs a multi-touch interface, such as sliding your finger across the screen to advance to the next page or pinching your fingers to zoom in or out of the screen.")
                .font(.body)
                .multilineTextAlignment(.leading)
                .padding(.all)
            
            Text("II. Introduction of Swift code")
                .font(.title)
                .fontWeight(.semibold)
                .multilineTextAlignment(.leading)
                .padding(.top)
                
            Image("MVVM")
                .resizable()
                .padding([.leading, .bottom, .trailing])
                .scaledToFit()
            
            Text("     Recently, Swift use a \"code organizing\" architectural design called \"Model-View-ViewModel\" or \"MVVM\". It must be adhered to SwiftUI to work. First, let me introduce model and view, there mechanisms in MVVM is hooked up to each other. Model is completely UI independent. The Model captures all the data and logica that describe \"what\" your application does. The View is \"how\" your app is presented to the user, but the Model is what your application actually is and does and the View is, therefore, always going to be a refelction of current state of the Model at all times. This means that the View is pretty much stateless. It does not need to store much in the way of state because all the truth about the state of things in the Model. The ViewModel's job is to bind the View to the Model so change in the model cause the View to react and get rebuilt. By the way, as it is doing that, it can also serve as a sort of interpreter between the Model and the View. For example, a ViewModel might present the data from a SQL database Model to a View as an Array or it might convert integers in some Model to floating point numbers or something that the view would prefer. When we look at the functions and the vars in the ViewModel that the View is allowed to call, they should be tuned to be \"exactly what the View needs to do its work\". This is why we say the ViewModel interprets the Model for the View. The ViewModel also serves as a gatekeeper for the Model and ensures that access to the Model is like well-behaved, especially when it comes to changing the Model. So when there is a change happening in the Model, then the ViewModel will track all the changes in the model, once noticed , it immediately publishes \"something changed\", so, when SwiftUI sees that a publishing event has happened for a View that is subscribed to that ViewModel's announcement, it asks the View for his body var and redraws it. When the view is providing that body var, it is looking at the current state of the Model and it's doing through ViewModel.")
                .font(.body)
                .multilineTextAlignment(.leading)
                .padding([.leading, .bottom, .trailing])
            
            Text("III. About this app")
                .font(.title)
                .fontWeight(.semibold)
                .multilineTextAlignment(.leading)
                .padding(.top)
            
            Text("     This app is designed for Hanlin Xu's Master thesis, it is made by a lot of small apps. This tutorial intends to demonstrate that ios platform can be used as a tool to develop cool Digital signal processing applications. It contents app like Text Edit and Fibonacci series etc. ")
            
        }
        
    }
}

struct IntroductionView_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionView()
.previewInterfaceOrientation(.portraitUpsideDown)
    }
}
