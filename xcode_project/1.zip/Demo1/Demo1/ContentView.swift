//
//  ContentView.swift
//  Demo1
//
//  Created by 徐晗淋 on 12/5/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView {
            Text("Demo 1: user interface")
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .font(.largeTitle)
                .padding(.top)
            
            Text("Designed by Hanlin Xu")
                .font(.headline)
                .foregroundColor(.secondary)
                            
                
            NavigationLink(destination:
                TextEditdemoView()){
                HStack{
                    Image(systemName: "highlighter")
                        .resizable()
                        .foregroundColor(Color.blue)
                        .padding(.trailing)
                        .frame(width: /*@START_MENU_TOKEN@*/40.0/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    Text("I.  Text Edition Demo")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.blue)
                    .padding(.vertical)
                }
            }
            
            NavigationLink(destination:
                Fibonacciseries1()){
                HStack{
                    Image(systemName: "list.number")
                        .resizable()
                        .foregroundColor(Color.blue)
                        .padding(.trailing)
                        .frame(width: /*@START_MENU_TOKEN@*/40.0/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    Text("II.  Fibonacci series")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.blue)
                    .padding(.vertical)
                    }
            }
                
            NavigationLink(destination:
                textimageView()){
                HStack{
                    Image(systemName: "list.number")
                        .resizable()
                        .foregroundColor(Color.blue)
                        .padding(.trailing)
                        .frame(width: /*@START_MENU_TOKEN@*/40.0/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    Text("III.  Text Image Demo")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.blue)
                    .padding(.vertical)
                    }
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
