//
//  Demo1App.swift
//  Demo1
//
//  Created by 徐晗淋 on 12/5/21.
//

import SwiftUI

@main
struct Demo1App: App {
    var body: some Scene {
        WindowGroup {
            TabView{
                NavigationView{
                    ContentView()
                }
                .tabItem{
                    Image(systemName: "laptopcomputer.and.iphone")
                    Text("Programming")
                }
                
                NavigationView{
                    IntroductionView()
                }
                .tabItem{
                    Image(systemName: "paperplane.circle.fill")
                    Text("Introduction")
                }
                }
            }
        }
    }

